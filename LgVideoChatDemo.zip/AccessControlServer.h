#pragma once
bool StartACServer(void);
bool StopACServer(void);
bool IsRunningACServer(void);
